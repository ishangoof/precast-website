package com.bits;

public class MailDomain {

	public String emailId ;
	public String subject;
	public PreviewDomain[] previewDomain;
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getSubject() {
		return subject;
	}
	public void setSubject(String subject) {
		this.subject = subject;
	}
	public PreviewDomain[] getPreviewDomain() {
		return previewDomain;
	}
	public void setPreviewDomain(PreviewDomain[] previewDomain) {
		this.previewDomain = previewDomain;
	}
	
}
