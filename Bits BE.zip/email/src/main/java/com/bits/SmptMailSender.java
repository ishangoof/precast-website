package com.bits;

import javax.mail.MessagingException;
import javax.mail.internet.MimeMessage;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.mail.javamail.MimeMessageHelper;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

@Component
public class SmptMailSender {

	@Autowired
	private JavaMailSender emailSender;
	
	public Boolean send(MailDomain mailObj) throws MessagingException {
		String products ="";
		MimeMessage message = emailSender.createMimeMessage();
		MimeMessageHelper helper;
		 helper = new MimeMessageHelper(message,true);
		 helper.setSubject("Order Invoice " + mailObj.getSubject());
		 helper.setTo(mailObj.getEmailId());
		 for(PreviewDomain Obj : mailObj.getPreviewDomain()) {
			 products  = products + Obj.getProductType().toUpperCase();
			 products = products + " ";
		 }
		 String body = "The following products have been ordered:" + products + ".For more info drop a mail to our customer care - bitsishan@gmail.com.";
		 helper.setText(body,true);
		 System.out.println("-----------------To address :" + message.getReplyTo() + "  ------------  "+ mailObj.getEmailId());
		 System.out.println("-----------------subject :" + message.getSubject() + "  ------------  ");
		 System.out.println("-----------------body :" + body + "  ------------  ");
		 emailSender.send(message);
		 
		 return true;
		
	}
}
