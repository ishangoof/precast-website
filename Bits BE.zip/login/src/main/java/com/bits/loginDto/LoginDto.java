package com.bits.loginDto;

import it.avutils.jmapper.annotations.JMap;
import lombok.Data;


@Data
public class LoginDto {

	public @JMap Integer loginId;	
	public @JMap String userName;
	public @JMap String loginPassword;	
	public @JMap Integer fkRegistrationId;
	public Boolean successFlag;
	
}

