package com.bits.loginDto;

import it.avutils.jmapper.annotations.JMap;

import javax.persistence.Column;

import lombok.Data;

@Data
public class RegistrationDto {

private @JMap Integer registrationId;
	
	public @JMap String userName;
	
	public @JMap String fullname;

	public @JMap String password;

	public @JMap String conPwd;
	public Boolean successFlag;
	
	/*public @JMap String address;
	
	public @JMap String dob;

	public @JMap String phoneNo;*/


}
