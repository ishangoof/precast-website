package com.bits.loginConversion;

import org.springframework.stereotype.Component;

import com.bits.loginDomain.RegistrationDomain;
import com.bits.loginDto.RegistrationDto;

@Component
public class RegistrationConversion {
public RegistrationDto convertDomaintoDto(RegistrationDomain obj){
	
	RegistrationDto dto = new RegistrationDto();
	dto.fullname = obj.getFullname();
	dto.userName = obj.getUserName();
	dto.password = obj.getPassword();
	dto.conPwd = obj.getConPwd();
/*	dto.dob = obj.getDob();
	dto.address = obj.getAddress();
	dto.phoneNo = obj.getPhoneNo();*/
	return dto;
}
}
