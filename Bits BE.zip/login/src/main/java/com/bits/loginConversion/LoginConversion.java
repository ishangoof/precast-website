package com.bits.loginConversion;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import com.bits.loginDomain.LoginDomain;
import com.bits.loginDto.LoginDto;


@Component
public class LoginConversion {
	public LoginDto convertToLoginDto (LoginDomain productObj){
		/*ModelMapper modelMapper = new ModelMapper();
		LoginDto dto = new LoginDto();
		dto = modelMapper.map(productObj, LoginDto.class);*/
		
		LoginDto dto = new LoginDto();
		dto.loginId = productObj.getLoginId();
		dto.loginPassword = productObj.getLoginPassword();
		dto.userName = productObj.getUserName();
		dto.fkRegistrationId = productObj.getFkRegistrationId();
		return dto;
	}
}