package com.bits.loginDomain;

import it.avutils.jmapper.annotations.JMap;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

@Entity
@Table(name = "Registration")
public class RegistrationDomain implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "pk_registration_id")
	@NotNull
	@GeneratedValue(strategy=GenerationType.AUTO)
	private @JMap Integer registrationId;
	
	@Column(name = "email_id")
	private @JMap String userName;
	
	@Column(name = "fullname")
	private @JMap String fullname;
	

	@Column(name = "password")
	private @JMap String password;
	

	@Column(name = "confirm_password")
	private @JMap String conPwd;
	

	/*@Column(name = "address")
	private @JMap String address;
	
	
	@Column(name = "dob")
	private @JMap String dob;
	

	@Column(name = "phone_no")
	private @JMap String phoneNo;*/


	public Integer getRegistrationId() {
		return registrationId;
	}


	public void setRegistrationId(Integer registrationId) {
		this.registrationId = registrationId;
	}


	public String getUserName() {
		return userName;
	}


	public void setUserName(String userName) {
		this.userName = userName;
	}


	public String getFullname() {
		return fullname;
	}


	public void setFullname(String fullname) {
		this.fullname = fullname;
	}


	public String getPassword() {
		return password;
	}


	public void setPassword(String password) {
		this.password = password;
	}


	public String getConPwd() {
		return conPwd;
	}


	public void setConPwd(String conPwd) {
		this.conPwd = conPwd;
	}
}

	/*public String getAddress() {
		return address;
	}


	public void setAddress(String address) {
		this.address = address;
	}


	public String getDob() {
		return dob;
	}


	public void setDob(String dob) {
		this.dob = dob;
	}


	public String getPhoneNo() {
		return phoneNo;
	}


	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}
	
	
	
}*/
