package com.bits.loginDomain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;

import it.avutils.jmapper.annotations.JMap;

@Entity
@Table(name = "login")
public class LoginDomain implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "pk_login_id")
	@NotNull
	@GeneratedValue(strategy=GenerationType.AUTO)
	private @JMap Integer loginId;
	
	@Column(name = "user_name")
	private @JMap String userName;

	@Column(name = "login_password")
	private @JMap String loginPassword;
	
	@Column(name = "fk_registration_id")
	private @JMap Integer fkRegistrationId;
	
	public Integer getLoginId() {
		return loginId;
	}

	public void setLoginId(Integer loginId) {
		this.loginId = loginId;
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getLoginPassword() {
		return loginPassword;
	}

	public void setLoginPassword(String loginPassword) {
		this.loginPassword = loginPassword;
	}

	public Integer getFkRegistrationId() {
		return fkRegistrationId;
	}

	public void setFkRegistrationId(Integer fkRegistrationId) {
		this.fkRegistrationId = fkRegistrationId;
	}

}
