package com.bits.loginService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bits.loginDomain.LoginDomain;
import com.bits.loginDomain.RegistrationDomain;
import com.bits.loginDto.LoginDto;
import com.bits.loginDto.RegistrationDto;
import com.bits.loginRepository.LoginRepository;
import com.bits.loginRepository.RegistrationRepository;

@Service
public class RegistrationService {

	@Autowired
	private RegistrationRepository repository;
	
	@Autowired
	private LoginRepository loginRep;
	
	public LoginDto add(RegistrationDomain obj){
		LoginDto dto = new LoginDto();
		
		obj = repository.saveAndFlush(obj);
		
		
		if(obj != null) {
			LoginDomain domainObj = new LoginDomain();
			domainObj.setLoginPassword(obj.getPassword());
			domainObj.setUserName(obj.getUserName());
			domainObj.setFkRegistrationId(obj.getRegistrationId());
			domainObj = loginRep.saveAndFlush(domainObj);
			if(domainObj != null) {
				dto.successFlag = true;
			return dto;
			}else {
				dto.successFlag = false;
				return dto;
			}
			
		}
		return dto;
	}
}
