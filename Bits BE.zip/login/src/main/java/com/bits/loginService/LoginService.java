package com.bits.loginService;



import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bits.loginConversion.LoginConversion;
import com.bits.loginDomain.LoginDomain;
import com.bits.loginDto.LoginDto;
import com.bits.loginRepository.LoginRepository;

@Service
public class LoginService {

	@Autowired
	private LoginConversion conversion;
	
	@Autowired
	private LoginRepository repository;
	
public LoginDto retrieve(String username,String password){
		String str = "";
		LoginDomain obj = repository.findByUserName(username);
		LoginDto dto = new LoginDto();
		if(obj != null && obj.getLoginPassword().equals(password) ) {
			str = "success";
			dto.successFlag = true;
		}else {
			str = "failure";
			dto.successFlag = false;
		}
		
	
	
		return dto;
	}
}
