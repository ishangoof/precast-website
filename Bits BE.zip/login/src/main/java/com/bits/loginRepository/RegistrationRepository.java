package com.bits.loginRepository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bits.loginDomain.RegistrationDomain;

@Repository
public interface RegistrationRepository extends JpaRepository<RegistrationDomain,Integer>{

}
