package com.bits.loginRepository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bits.loginDomain.LoginDomain;


@Repository
public interface LoginRepository extends JpaRepository<LoginDomain,Integer> {

	LoginDomain findByUserName(String username);
}
