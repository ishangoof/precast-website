package com.bits.loginController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bits.loginDomain.RegistrationDomain;
import com.bits.loginDto.LoginDto;
import com.bits.loginService.RegistrationService;

@RestController
@CrossOrigin
@RequestMapping(value = "/register", headers = {"content-type=application/json" }, consumes = MediaType.ALL_VALUE,produces =  MediaType.ALL_VALUE)
public class RegistrationController {
	
	@Autowired
	private RegistrationService service;

	@PostMapping(path = "/add")
	public ResponseEntity<LoginDto> add(@RequestBody RegistrationDomain obj){
		 LoginDto dto = service.add(obj);
		 
		 return new ResponseEntity<LoginDto>(dto, HttpStatus.OK);		
	}


}
