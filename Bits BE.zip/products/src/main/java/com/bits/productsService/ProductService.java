package com.bits.productsService;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bits.productsConversion.ProductConversion;
import com.bits.productsDomain.ProductsDomain;
import com.bits.productsDto.ProductDto;
import com.bits.productsRepository.materialRepository;
import com.bits.productsRepository.productRepository;


@Service
public class ProductService {

	@Autowired
	private productRepository repository;
	
	@Autowired
	private materialRepository materialRep;
	
	@Autowired
	ProductConversion conversion;
	
	public List<ProductDto> retrieve(){
		
		List<ProductsDomain> obj = repository.findAll();
		
		List<ProductDto> dtoList = new ArrayList<>();
		
		for(ProductsDomain prod :obj){
			ProductDto dto = conversion.convertToProductDto(prod);
			dtoList.add(dto);
		}
		
		return dtoList;
	}
	
	public ProductDto add(List<ProductsDomain> obj) {
		ProductsDomain saveObj = null;
		for(ProductsDomain pd : obj) {
			 saveObj = repository.save(pd);
		}
		ProductDto saveDto = conversion.convertToProductDto(saveObj);
		return saveDto;
	}
}
