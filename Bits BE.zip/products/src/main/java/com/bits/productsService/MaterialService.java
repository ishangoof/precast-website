package com.bits.productsService;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bits.productsConversion.MaterialConversion;
import com.bits.productsConversion.ProductConversion;
import com.bits.productsDomain.MaterialDomain;
import com.bits.productsDomain.ProductsDomain;
import com.bits.productsDto.ProductDto;
import com.bits.productsDto.materialDto;
import com.bits.productsRepository.materialRepository;

@Service
public class MaterialService {
	
	@Autowired
	MaterialConversion conversion;
	
	@Autowired
	private materialRepository materialRep;
	
	public List<materialDto> add(List<MaterialDomain> obj) {
		MaterialDomain saveObj = null;
		List<MaterialDomain> list = new ArrayList<>();
		for(MaterialDomain md : obj){
			saveObj = materialRep.save(md);
			list.add(saveObj);}
		List<materialDto> dto = conversion.convertToListMaterialDto(list);
		return dto;
	}
	
public List<materialDto> retrieve(){
		
		List<MaterialDomain> obj = materialRep.findAll();
		
		List<materialDto> dtoList = new ArrayList<>();
		
		for(MaterialDomain prod :obj){
			materialDto dto = conversion.convertToMaterialDto(prod);
			dtoList.add(dto);
		}
		
		return dtoList;
	}
	
}
