package com.bits.productsDto;

import it.avutils.jmapper.annotations.JMap;
import lombok.Data;

@Data
public class ProductDto {

	public @JMap Integer productId;	
	public @JMap String productName;	
	public @JMap String productDescription;	
	public @JMap String productSize;	
	public @JMap Integer productCost;	
	public @JMap String costDenotation;
	public @JMap String productPic;	
	public @JMap String materialType;
	
}
