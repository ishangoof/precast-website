package com.bits.productsDto;

import it.avutils.jmapper.annotations.JMap;
import lombok.Data;

@Data
public class materialDto {

	public @JMap Integer materialId;	
	public @JMap String materialType;	
}
