package com.bits.productsConversion;

import org.springframework.stereotype.Component;
import org.modelmapper.ModelMapper;
import com.bits.productsDomain.ProductsDomain;
import com.bits.productsDto.ProductDto;

@Component
public class ProductConversion {
	public ProductDto convertToProductDto (ProductsDomain productObj){
//		ModelMapper modelMapper = new ModelMapper();
//		ProductDto dto = new ProductDto();
//		dto = modelMapper.map(productObj, ProductDto.class);
		
		ProductDto dto = new ProductDto();
		dto.materialType = productObj.getMaterialType();
		dto.productId = productObj.getProductId();
		dto.productDescription = productObj.getProductDescription();
		dto.productCost = productObj.getProductCost();
		dto.costDenotation = productObj.getCostDenotation();
		dto.productName = productObj.getProductName();
		dto.productSize = productObj.getProductSize();
		dto.productPic = productObj.getProductPic();
		
		
		return dto;
	}
}
