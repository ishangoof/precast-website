package com.bits.productsConversion;

import java.util.ArrayList;
import java.util.List;

import org.modelmapper.ModelMapper;
import org.springframework.stereotype.Component;

import com.bits.productsDomain.MaterialDomain;
import com.bits.productsDomain.ProductsDomain;
import com.bits.productsDto.ProductDto;
import com.bits.productsDto.materialDto;


@Component
public class MaterialConversion {
	public List<materialDto> convertToListMaterialDto (List<MaterialDomain> materialObj){
		ModelMapper modelMapper = new ModelMapper();
		materialDto dto = new materialDto();
		List<materialDto> list = new ArrayList<>();
		for(MaterialDomain obj : materialObj){
//		dto = modelMapper.map(obj, materialDto.class);
			dto.materialId = obj.getMaterialId();
			dto.materialType = obj.getMaterialType();
		list.add(dto);
		}
		
		
		return list;
	}
	public materialDto convertToMaterialDto (MaterialDomain materialObj){
		ModelMapper modelMapper = new ModelMapper();
		materialDto dto = new materialDto();
		dto.materialId = materialObj.getMaterialId();
					dto.materialType = materialObj.getMaterialType();
		
		return dto;
	}
}