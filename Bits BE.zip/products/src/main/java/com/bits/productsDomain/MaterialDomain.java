package com.bits.productsDomain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import it.avutils.jmapper.annotations.JMap;

@Entity
@Table(name = "material")
public class MaterialDomain implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "pk_material_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private @JMap Integer materialId;
	
	@Column(name = "material_type")
	private @JMap String materialType;

	public Integer getMaterialId() {
		return materialId;
	}

	public void setMaterialId(Integer materialId) {
		this.materialId = materialId;
	}

	public String getMaterialType() {
		return materialType;
	}

	public void setMaterialType(String materialType) {
		this.materialType = materialType;
	}

}
