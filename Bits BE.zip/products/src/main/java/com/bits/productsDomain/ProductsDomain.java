package com.bits.productsDomain;

import java.io.Serializable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;

import it.avutils.jmapper.annotations.JMap;

@Entity
@Table(name = "products")
public class ProductsDomain implements Serializable{

	private static final long serialVersionUID = 1L;
	
	@Id
	@Column(name = "pk_product_id")
	@GeneratedValue(strategy=GenerationType.AUTO)
	private @JMap Integer productId;
	
	@Column(name = "product_name")
	private @JMap String productName;
	
	@Column(name = "product_description")
	private @JMap String productDescription;
	
	@Column(name = "product_size")
	private @JMap String productSize;
	
	@Column(name = "product_cost")
	private @JMap Integer productCost;
	
	@Column(name = "product_cost_denotation")
	private @JMap String costDenotation;
	
	@Column(name = "product_pic")
	private @JMap String productPic;
	
	@Column(name = "material_type")
	private @JMap String materialType;

	public Integer getProductId() {
		return productId;
	}

	public void setProductId(Integer productId) {
		this.productId = productId;
	}

	public String getProductName() {
		return productName;
	}

	public void setProductName(String productName) {
		this.productName = productName;
	}

	public String getProductDescription() {
		return productDescription;
	}

	public void setProductDescription(String productDescription) {
		this.productDescription = productDescription;
	}

	public String getProductSize() {
		return productSize;
	}

	public void setProductSize(String productSize) {
		this.productSize = productSize;
	}

	

	public Integer getProductCost() {
		return productCost;
	}

	public void setProductCost(Integer productCost) {
		this.productCost = productCost;
	}

	public String getCostDenotation() {
		return costDenotation;
	}

	public void setCostDenotation(String costDenotation) {
		this.costDenotation = costDenotation;
	}

	public String getProductPic() {
		return productPic;
	}

	public void setProductPic(String productPic) {
		this.productPic = productPic;
	}

	public String getMaterialType() {
		return materialType;
	}

	public void setMaterialType(String materialType) {
		this.materialType = materialType;
	}
		
}
