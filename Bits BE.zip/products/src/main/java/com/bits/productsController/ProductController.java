package com.bits.productsController;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bits.productsDomain.ProductsDomain;
import com.bits.productsDto.ProductDto;
import com.bits.productsService.ProductService;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;

@RestController
@CrossOrigin
@RequestMapping(value = "/product", headers = {"content-type=application/json" }, consumes = MediaType.ALL_VALUE,produces =  MediaType.APPLICATION_JSON_VALUE)
public class ProductController {

	@Autowired
	private ProductService service;

	@GetMapping(path = "/list")
	public ResponseEntity<List<ProductDto>> retrieve(){
		List<ProductDto> dto = service.retrieve();
		return new ResponseEntity<List<ProductDto>>(dto, HttpStatus.OK);
	}
	
	@PostMapping(path = "/add")
	public ResponseEntity<ProductDto> add(@RequestBody List<ProductsDomain> obj){
		 ProductDto str = service.add(obj);
		 
		 return new ResponseEntity<ProductDto>(str, HttpStatus.OK);		
	}

}
