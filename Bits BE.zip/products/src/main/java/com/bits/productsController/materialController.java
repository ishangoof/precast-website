package com.bits.productsController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bits.productsDomain.MaterialDomain;
import com.bits.productsDomain.ProductsDomain;
import com.bits.productsDto.ProductDto;
import com.bits.productsDto.materialDto;
import com.bits.productsService.MaterialService;

@RestController
@CrossOrigin
@RequestMapping(value = "/material", headers = {"content-type=application/json" }, consumes = MediaType.ALL_VALUE,produces =  MediaType.APPLICATION_JSON_VALUE)
public class materialController {

	@Autowired
	private MaterialService service;
	
	@GetMapping(path="list")
	public ResponseEntity<List<materialDto>> retrieve(){
		List<materialDto> dto = service.retrieve();
		return new ResponseEntity<List<materialDto>>(dto, HttpStatus.OK);
	}
	
	
	@PostMapping(path = "/add")
	public ResponseEntity<List<materialDto>> add(@RequestBody List<MaterialDomain> obj){
		List<materialDto> str =service.add(obj);
		 return new ResponseEntity<List<materialDto>>(str, HttpStatus.OK);		
	}
}
