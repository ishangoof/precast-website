package com.bits.productsRepository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.bits.productsDomain.MaterialDomain;

@Repository
public interface materialRepository extends JpaRepository<MaterialDomain,Integer>{


}
