package com.bits.productsRepository;

import org.springframework.stereotype.Repository;
import com.bits.productsDomain.ProductsDomain;
import org.springframework.data.jpa.repository.JpaRepository;

@Repository
public interface productRepository extends JpaRepository<ProductsDomain,Integer> {

}
