package com.bits.purchaseController;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bits.purchaseDomain.purchaseDomain;
import com.bits.purchaseDto.purchaseDto;
import com.bits.purchaseService.purchaseService;

@RestController
@CrossOrigin
@RequestMapping(value = "/purchase", headers = {"content-type=application/json" }, consumes = MediaType.ALL_VALUE,produces =  MediaType.APPLICATION_JSON_VALUE)
public class purchaseController {
	
	
	@Autowired
	private purchaseService service;

	@PostMapping(path = "/add")
	public ResponseEntity<List<purchaseDto>> add(@RequestBody List<purchaseDomain> obj){
		List<purchaseDto> str = service.add(obj);
		 
		 return new ResponseEntity<List<purchaseDto>>(str, HttpStatus.OK);		
	}
}
