package com.bits.purchaseDomain;

import java.io.Serializable;
import java.util.Date;

import it.avutils.jmapper.annotations.JMap;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name = "purchase")
public class purchaseDomain implements Serializable{
	private static final long serialVersionUID = 1L;

@Id
@Column(name = "pk_order_id")
@GeneratedValue(strategy=GenerationType.AUTO)
private @JMap Integer orderId;


@Column(name = "purchase_id")
private @JMap String purchaseId;
	
@Column(name = "material_type")
private @JMap String materialType;
	
@Column(name = "material_id")
private @JMap Integer materialId;

@Column(name = "product_type")
private @JMap String productType;
	
@Column(name = "product_id")
private @JMap Integer productId;
			
@Column(name = "unit_count")
private @JMap Integer noOfUnits;

@Column(name = "dop")
private @JMap Date dateOfPurchase;

public Integer getOrderId() {
	return orderId;
}

public void setOrderId(Integer orderId) {
	this.orderId = orderId;
}

public String getMaterialType() {
	return materialType;
}

public void setMaterialType(String materialType) {
	this.materialType = materialType;
}

public Integer getMaterialId() {
	return materialId;
}

public void setMaterialId(Integer materialId) {
	this.materialId = materialId;
}

public String getProductType() {
	return productType;
}

public void setProductType(String productType) {
	this.productType = productType;
}

public Integer getProductId() {
	return productId;
}

public void setProductId(Integer productId) {
	this.productId = productId;
}

public Integer getNoOfUnits() {
	return noOfUnits;
}

public void setNoOfUnits(Integer noOfUnits) {
	this.noOfUnits = noOfUnits;
}

public String getPurchaseId() {
	return purchaseId;
}

public void setPurchaseId(String purchaseId) {
	this.purchaseId = purchaseId;
}

public Date getDateOfPurchase() {
	return dateOfPurchase;
}

public void setDateOfPurchase(Date dateOfPurchase) {
	this.dateOfPurchase = dateOfPurchase;
}


	
}
