package com.bits.purchaseDto;

import java.util.Date;

import it.avutils.jmapper.annotations.JMap;
import lombok.Data;

@Data
public class purchaseDto {

public @JMap Integer orderId;
	
	public @JMap String materialType;		
	
	public @JMap Integer materialId;	
	
	public @JMap String productType;		
	
	public @JMap Integer productId;				
	
	public @JMap Integer noOfUnits;
	
	public @JMap String purchaseId;
	
	public @JMap Date dateOfPurchase;
}
