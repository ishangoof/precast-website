package com.bits.purchaseService;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.bits.purchaseConverter.purchaseConverter;
import com.bits.purchaseDomain.purchaseDomain;
import com.bits.purchaseDto.purchaseDto;
import com.bits.purchaseRepository.purchaseRepository;

@Service
public class purchaseService {

	@Autowired
	private purchaseRepository repository;

	@Autowired
	private purchaseConverter conversion;

	static int count = 0;

	public List<purchaseDto> add(List<purchaseDomain> domainObj) {
		List<purchaseDto> dto = new ArrayList<>();
		String tempPurchaseId = "";

		for (purchaseDomain obj : domainObj) {

			if (count != 0) {
				obj.setPurchaseId(tempPurchaseId);
			}

			obj = repository.saveAndFlush(obj);

			if (count == 0) {
				obj.setPurchaseId("OI" + obj.getOrderId());
				count++;
				tempPurchaseId = obj.getPurchaseId();
				obj = repository.saveAndFlush(obj);
			}

			dto.add(conversion.convertDomainToDto(obj));

		}
		count = 0;
		return dto;
	}
}
