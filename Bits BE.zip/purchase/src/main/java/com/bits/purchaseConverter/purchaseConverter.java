package com.bits.purchaseConverter;

import org.springframework.stereotype.Component;

import com.bits.purchaseDomain.purchaseDomain;
import com.bits.purchaseDto.purchaseDto;


@Component
public class purchaseConverter {
	
	public purchaseDto convertDomainToDto (purchaseDomain obj){
		purchaseDto dto = new purchaseDto();
		dto.orderId = obj.getOrderId();
		dto.materialId = obj.getMaterialId();
		dto.materialType = obj.getMaterialType();
		dto.productId = obj.getProductId();
		dto.productType = obj.getProductType();
		dto.noOfUnits = obj.getNoOfUnits();
		dto.purchaseId = obj.getPurchaseId();
		dto.dateOfPurchase = obj.getDateOfPurchase();
		
		return dto;
	}

}
