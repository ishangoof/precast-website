import { Component, OnInit, ViewChild } from '@angular/core';
import {  TabDirective } from 'ngx-bootstrap';
@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

 aboutTabEnable = true;
 productTabEnable = false;
 orderTabEnable = false;
  constructor() { }

  ngOnInit() {
  }

  onTabSelect(data: TabDirective, region: string): void {
    if  (data.heading === 'About') {
    this.aboutTabEnable = true;
    this.productTabEnable = false;
    this.orderTabEnable = false;
    }
    if (data.heading === 'Products') {
      this.aboutTabEnable = false;
      this.productTabEnable = true;
      this.orderTabEnable = false;
    }
    if (data.heading === 'Order') {
      this.aboutTabEnable = false;
      this.productTabEnable = false;
      this.orderTabEnable = true;
    }
  }
}
