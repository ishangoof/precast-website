import { Component, OnInit, ViewChild } from '@angular/core';
import { ProductServiceService } from '../service/product-service.service';
import { OrderService } from '../service/order.service';
import { BsModalRef, ModalDirective } from 'ngx-bootstrap';
import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';

declare var $: any;
declare function unescape(s: string): string;
declare function escape(s: string): string;

@Component({
  selector: 'app-order-page',
  templateUrl: './order-page.component.html',
  styleUrls: ['./order-page.component.css']
})
export class OrderPageComponent implements OnInit {

  materialTypeOptions: any;
  productOptions = [];
  tableData = [];
  dropDownOption: any;
  productDetails: any;
  unitNo: number = 0;
  product: any = [];
  material: any = [];
  productLen = 0;
  config: any;
  productConfig: any;
  totalVal: any;
  totalCost: number = 0;
  totalUnits: number = 0;
  orderData: any;
  emailId: any;
  popUpData: any;
  /* orderTabEnable  = true;
  aboutTabEnable = false; */

  @ViewChild('previewModal') popModal: ModalDirective;
  @ViewChild('emailModal') emailPopUp: ModalDirective;


  constructor(public toastr: ToastrService, public productservice: ProductServiceService,
              public orderService: OrderService, public router: Router) {
  }

  ngOnInit() {
    this.productservice.getProductData().subscribe((resp) => {
      this.productDetails = resp;
      this.productConfig = {
        displayKey: 'productName',
        search: true,
        height: 'auto',
        placeholder: 'Select',
        limitTo: this.productDetails.length,
        moreText: 'more',
        noResultsFound: 'No results found!',
        searchPlaceholder: 'Search',
        searchOnKey: 'name'
      };
    });
    this.productservice.getMaterialData().subscribe((resp) => {
      this.materialTypeOptions = resp;
      this.config = {
        displayKey: 'materialType',
        search: true,
        height: 'auto',
        placeholder: 'Select',
        limitTo: this.materialTypeOptions.length,
        moreText: 'more',
        noResultsFound: 'No results found!',
        searchPlaceholder: 'Search',
        searchOnKey: 'name'
      };

    });

  }

  checkData() {
    this.dropDownOption = this.productOptions;
  }

  materialChanged(val) {
    this.productOptions = [];
    // this.product = null;
    this.productDetails.forEach(el => {
      if (el.materialType === val.value.materialType) {
        const rowData = {
          id: el.productId,
          description: el.productName
        };
        this.productOptions.push(rowData);
      }
    });

    this.productConfig = {
      displayKey: 'description',
      search: true,
      height: 'auto',
      placeholder: 'Select',
      limitTo: this.productOptions.length,
      moreText: 'more',
      noResultsFound: 'No results found!',
      searchPlaceholder: 'Search',
      searchOnKey: 'name'
    };

    console.log('------' + this.productConfig.limitTo);

  }

  add() {
    console.log(this.unitNo + '--- Unit No');
    console.log(this.product.description + '--- Product type ');
    console.log(this.material.materialId + '--- material id ');
    console.log(this.material.materialType + '--- material type');
    console.log(this.product.id + '--- product id');
    const tableDetails = {
      noOfUnits: this.unitNo,
      dateOfPurchase: new Date(),
      productType: this.product.description,
      materialType: this.material.materialType,
      materialId: this.material.materialId,
      productId: this.product.id
    };
    this.tableData.push(tableDetails);

    this.totalUnits += this.unitNo;

    this.productDetails.forEach(val => {
      if (val.productId === this.product.id) {
        this.totalCost += (this.unitNo * val.productCost);
      }
    });
  }

  order(rowDetails) {
    console.log('Need to create a preview for confirming the order');
    // this.tableData;


    this.orderService.postOrderData(rowDetails).subscribe((resp) => {
      // console.log(resp + 'success');
      this.orderData = resp;
      this.call(this.orderData);
    });
  }

  call(data: any) {
    console.log(data);
    this.popUpData = data;

    this.popModal.show();
  }

  sendEmailPopup() {
    const mailObj = {
      emailId: this.emailId,
      subject: this.popUpData[0].purchaseId,
      previewDomain: this.popUpData

    };
    this.productservice.sendEmail(mailObj).subscribe((resp) => {
      console.log('email sent');
      this.toastr.success('Email has been sent.');
      this.emailPopUp.hide();
    });
  }

  sendEmail() {
    this.emailPopUp.show();
  }

  closePreview() {
    this.popModal.hide();
  }

  ExportToExcel(id: any, workSheetName: any, subFileName: any) {

    tableToExcel(id, workSheetName, subFileName);
  }
}


const tableToExcel = (function () {
  const uri = 'data:application/vnd.ms-excel;base64,';
  const template = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-mic' +
    'rosoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40"><head><!--[if g' +
    'te mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>{wo' +
    'rksheet}</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions><' +
    '/x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head' +
    '><body><table>{table}</table></body></html>';
  const base64 = function (s) {
    return window.btoa(unescape(encodeURIComponent(s)));
  };
  const format = function (s, c) {
    return s.replace(/{(\w+)}/g, function (m, p) {
      return c[p];
    });
  };
  return function (table, name, fileName) {
    if (!table.nodeType) {
      table = document.getElementById(table);
    }
    const ctx = {
      worksheet: name || 'Worksheet',
      table: table.innerHTML
    };
    // window.location.href = uri + base64(format(template, ctx))
    if (window.navigator.msSaveBlob) {
      const blob = b64toBlob(base64(format(template, ctx)), 'application/vnd.ms-excel', 512);
      window
        .navigator
        .msSaveBlob(blob, fileName + '.xls');
    } else if (window.URL.createObjectURL) {

      window.location.href = uri + base64(format(template, ctx));

      //  window.URL.createObjectURL(  window.location.href
      // ,'application/vnd.ms-excel', 'SingleRiskScore.xls');

    }

  };
})();

// Excel excelReportObj
function b64toBlob(b64Data, contentType, sliceSize) {
  // function taken from http://stackoverflow.com/a/16245768/2591950 author Jeremy
  // Banks http://stackoverflow.com/users/1114/jeremy-banks
  contentType = contentType || '';
  sliceSize = sliceSize || 512;

  const byteCharacters = window.atob(b64Data);
  const byteArrays = [];

  let offset;
  for (offset = 0; offset < byteCharacters.length; offset += sliceSize) {
    const slice = byteCharacters.slice(offset, offset + sliceSize);

    const byteNumbers = new Array(slice.length);
    let i;
    for (i = 0; i < slice.length; i = i + 1) {
      byteNumbers[i] = slice.charCodeAt(i);
    }

    const byteArray = new Uint8Array(byteNumbers);

    byteArrays.push(byteArray);
  }

  const blob = new window.Blob(byteArrays, { type: contentType });
  return blob;
}
