import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';


@Injectable({
  providedIn: 'root'
})
export class OrderService {

  constructor(private http: HttpClient) { }

  url = 'http://localhost:8088/purchase/add';

  public postOrderData(data): Observable<any[]> {
    let headersValue = new HttpHeaders();
    headersValue = headersValue.set('Access-Control-Allow-Origin', '*');
    headersValue = headersValue.set('Content-Type', 'application/json');
       return this.http.post<any[]>(this.url, data, { headers: headersValue });
  }
}
