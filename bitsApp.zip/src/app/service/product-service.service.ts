import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class ProductServiceService {

  constructor(private http: HttpClient) { }
  url = 'http://localhost:8084/product/list';
  url1 = 'http://localhost:8084/material/list';
  url2 = 'http://localhost:8044/email/send';
  public getProductData(): Observable <any> {
    let headersValue = new HttpHeaders();
    headersValue = headersValue.set('Access-Control-Allow-Origin', '*');
    headersValue = headersValue.set('Content-Type', 'application/json');
    return this.http.get<any>(this.url, { headers: headersValue });

  }

  public sendEmail(data): Observable<any[]> {
    let headersValue = new HttpHeaders();
    headersValue = headersValue.set('Access-Control-Allow-Origin', '*');
    headersValue = headersValue.set('Content-Type', 'application/json');
    return this.http.post<any[]>(this.url2, data, { headers: headersValue });
    

  }


  public getMaterialData(): Observable <any> {
    let headersValue = new HttpHeaders();
    headersValue = headersValue.set('Access-Control-Allow-Origin', '*');
    headersValue = headersValue.set('Content-Type', 'application/json');
    return this.http.get<any>(this.url1, { headers: headersValue });

  }
}
