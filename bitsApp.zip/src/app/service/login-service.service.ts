import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpHeaders, HttpRequest } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LoginServiceService {

  url = 'http://localhost:8089/login/check';
  constructor( private http: HttpClient) { }

   public checkLogin(userName, password): Observable <any> {
    let headersValue = new HttpHeaders();
    headersValue = headersValue.set('Access-Control-Allow-Origin', '*');
    headersValue = headersValue.set('Content-Type', 'application/json');
    headersValue = headersValue.set('userName', userName);
    headersValue = headersValue.set('password', password);
    return this.http.get<any[]>(this.url, { headers: headersValue });
}
}
