import { Component, OnInit, ViewChild } from '@angular/core';
import { BsModalRef, ModalDirective } from 'ngx-bootstrap';
import {ProductServiceService} from '../service/product-service.service';


@Component({
  selector: 'app-products-page',
  templateUrl: './products-page.component.html',
  styleUrls: ['./products-page.component.css']
})
export class ProductsPageComponent implements OnInit {

  productDetails: any;
  materialDetails: any;
  productId: any;
  materialId: any;
  materialType: any;
  productName: any;
  productDescription: any;
  productSize: any;
  productCost: any;
  popUpData: any;
  productPic: any;

  modalRef: BsModalRef;

  @ViewChild('previewModal') popModal: ModalDirective;

  constructor(public productservice: ProductServiceService) { }

  ngOnInit() {
    this.productservice.getProductData().subscribe((resp) => {
      this.productDetails = resp;
    });
    this.productservice.getMaterialData().subscribe((resp) => {
      this.materialDetails = resp;
    });

  }

  call(data: any) {
    console.log(data);
    this.popUpData = data;
    this.popModal.show();
  }

  closePreview() {
    this.popModal.hide();
  }
}
