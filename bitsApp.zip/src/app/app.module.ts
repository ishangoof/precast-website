import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { HomeComponent } from './home/home.component';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import {RouterModule, Routes} from '@angular/router';
import { AboutPageComponent } from './about-page/about-page.component';
import { ProductsPageComponent } from './products-page/products-page.component';
import { OrderPageComponent } from './order-page/order-page.component';
import { ModalModule, TabsModule} from 'ngx-bootstrap';
import { HttpClientModule } from '@angular/common/http';
import { HttpModule } from '@angular/http';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { ToastrModule } from 'ngx-toastr';
import { SelectDropDownModule } from 'ngx-select-dropdown';
import { LoginServiceService } from 'src/app/service/login-service.service';

const appRoutes: Routes = [
  { path: 'home', component : HomeComponent},
  { path: 'about', component : AboutPageComponent},
  { path: 'product', component : ProductsPageComponent},
  { path: 'order', component : OrderPageComponent},
  { path: 'login', component : LoginComponent},
  { path: 'registration', component : RegistrationComponent},
  { path: '', redirectTo : '/login', pathMatch: 'full'}
];
@NgModule({
  declarations: [
    AppComponent,
    HomeComponent,
    AboutPageComponent,
    ProductsPageComponent,
    OrderPageComponent,
    LoginComponent,
    RegistrationComponent
  ],
  imports: [
    FormsModule,
    BrowserAnimationsModule,
    SelectDropDownModule,
    RouterModule.forRoot(appRoutes),
    TabsModule.forRoot(),
    ModalModule.forRoot(),
    BrowserModule,
    HttpModule,
    HttpClientModule,
    AppRoutingModule,
    ToastrModule.forRoot({
      timeOut: 5000,
      extendedTimeOut: 1000,
      closeButton: true,
      enableHtml: true,
      preventDuplicates: true,
    }),
  ],
  providers: [LoginServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
