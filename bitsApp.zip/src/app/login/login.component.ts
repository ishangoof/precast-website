import { Component, OnInit, ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { LoginServiceService } from '../service/login-service.service';
import { Router } from '@angular/router';
import { BsModalRef, ModalDirective } from 'ngx-bootstrap';



@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  @ViewChild('previewModal') popModal: ModalDirective;
  userName: any = '';
  pwd: any = '';
  result: any;
  constructor(private toastr: ToastrService, public loginService: LoginServiceService, public router: Router) { }

  ngOnInit() {
  }

  validate() {
    console.log('need to validate');
    this.loginService.checkLogin(this.userName, this.pwd).subscribe((resp) => {
      console.log(resp);
      if (resp.successFlag) {
        this.router.navigateByUrl('/home');
      }
      if (!resp.successFlag) {
        window.alert('Login failed please check the credentials entered !!!');
        /* this.popModal.show();
        this.toastr.error('Login failed please check the credentials entered !!!'); */
      }
    });
  }

  closePopUp() {
    this.popModal.hide();
  }
}
