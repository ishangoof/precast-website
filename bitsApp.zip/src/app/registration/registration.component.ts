import { Component, OnInit } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import {RegisterService} from '../service/register.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {



  userName: any = '';
  fullname: any = '';
  password: any = '';
  conPwd: any = '';
  address: any = '';
  dob: any = '';
  phoneNo: any = '';
  match: boolean = false;
  termsCB: boolean = false;

  constructor(private toastr: ToastrService, public registerService: RegisterService, public router: Router) { }

  ngOnInit() {

  }
  register() {

    if (this.password.trim() === this.conPwd.trim()) {
      console.log('match');
      this.match = true;
    }

    if (this.match) {
      const data = {
        userName : this.userName,
        fullname: this.fullname,
        password: this.password,
        conPwd: this.conPwd,
        /* address: this.address,
        phoneNo: this.phoneNo,
        dob: this.dob */
      };
      this.registerService.registerData(data).subscribe((resp) => {
        console.log(resp + 'success');
        if (resp.successFlag) {
          this.toastr.success('Registered Successfully!!');
          this.router.navigateByUrl('/login');
        }
        if (!resp.successFlag) {
          window.alert('Please check the entered data');
          /* this.toastr.error('Please check the entered data'); */
        }
      });
    }
  }

}
